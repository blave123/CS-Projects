**CS174a Final Project: Snake **

**<u>Team:</u>**

Jonathan Li,      UID: 905131459

Guanqun Ma,   UID: 305331164 

Ping-Yang Gao, UID: 705550847



<u>**Introduction**:</u>

For our project we decided to create a game similar to the classic Snake that is instead in a 3d environment. The player controls the snake and avoids tall rock structures while trying to collect cookies. In the north of where the player spawns there exists a rock monster. This monster can only be defeated after collecting 5 or more cookies(notified when the texture of the snake changes), otherwise the player is too weak and will be killed by the monster. The game is won after you collect 5+ cookies and defeat the rock monster. 

**Controls:**

(P) : start game

(R) : restart game

( J ) : snake move left

(L) : snake move right



<u>**Advanced Features:**</u>

**Scene Graphs**:

We used scene graphs to create different scenes for the first screen, victory screen, and death screen of the game. Each screen contains text to show players what has happened/instructions of the game for the first screen. Each screen also contains its own music.

<u>Implementation</u>

For our implementation we first created the different scenes or screens for the events mentioned above. This is done by creating a cube and subsequently adding text as a texture to the cube. The cube is then rotated based on which screen you must reach. Then for the display of these scenes, we created an if else hierarchal structure of booleans to control which screen you are shown. When you first start the game the default screen shown in this structure will be the starting screen. After clicking (P) a boolean will be turned true which will leave this screen and begin the game. Once you begin the game this game will now continue until you prompt 1 of 2 events. First, if you die with any means you will turn two booleans true, one to notify that the game has ended and one to notify that you have lost. This occurs when colliding with a wall, rock, or boss with insufficient size. Second, if you collect enough cookies and collide with the boss you will turn 2 booleans true, 1 for game has ended, and 1 for you have won. Whenever the game has ended boolean is turned true the game will obviously end and then based on the gamelost/gamewon booleans you will reach your respective screen. At the end there is a function to fully reset the game which can be activated by (R).

**Collision Detection:**

We used collision detection to make events occur when the snake collides with certain objects. When the snake collides with a cookie, the cookie disappears and the snake grows in length by 1 sphere. When the snake collides with the boundary walls or a tall rock the game will end and the game over screen will be reached. For the rock monster, if the snake collides with the rock monster without collecting at least 5 cookies the game will end similar to a wall collision, but if the snake has collected enough cookies the game will end and the player will reach a different victory screen with accompanying music.

<u>Implementation</u>:

 For our snake the coordinates of each snake "part" (each sphere of the snake) is stored within 2 different vectors. Because of this the very first sphere or head of the snake is stored in the [0] element of these 2 vectors and this is what we use to detect all of our collisions. The coordinates of every other object in the game is also stored in their own vectors. So to detect collision we simply compare the coordinates of the snake head with the coordinates of these objects, and (based on the size of the object) give them a degree of distance to which the snake can reach before being counted as a collision. 



**<u>References</u>**

**3d models:**

Rock wall : https://www.turbosquid.com/3d-models/free-rock-wall-3d-model/618363
Tall grass: https://free3d.com/3d-model/high-quality-grass-78178.html
Rock boss: https://free3d.com/3d-model/giant-stone-765391.html
Tall rock: https://www.turbosquid.com/3d-models/mountain-rock-pbr-8k-3d-model-1300107
Food: https://www.turbosquid.com/3d-models/3d-santa-claus-model-1478073
Rock: https://www.turbosquid.com/3d-models/rock-cliff-3d-model-1623414



**<u>Environment:</u>** For this project we used Assignment 2 as our environment, though none of the code in Assignment 2 is actually vital or necessary in our project.

