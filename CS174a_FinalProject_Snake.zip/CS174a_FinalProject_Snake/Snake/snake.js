import {defs, tiny} from './examples/common.js';
import { Shape_From_File } from './examples/obj-file-demo.js';
import {Text_Line} from './examples/text-demo.js'

const {
    Vector, Vector3, vec, vec3, vec4, color, hex_color, Shader, Matrix, Mat4, Light, Shape, Material, Scene, Texture,
} = tiny;

const {Cube, Axis_Arrows, Textured_Phong, Phong_Shader} = defs

export class Snake extends Scene {
    /**
     *  **Base_scene** is a Scene that can be added to any display canvas.
     *  Setup the shapes, materials, camera, and lighting here.
     */
    constructor() {
        // constructor(): Scenes begin by populating initial values like the Shapes and Materials they'll need.
        super();

        this.startGame = false;
        this.endGame = false;
        this.background_music = new Audio('main_music.mp3');

        // For tracking victory
        // when snake eats the boss, this sets to true
        this.victory = false;

        // For lose the game
        // when the snake touches anything other than food and grass, the snake dies and this sets to true
        this.loseGame = false;

        // Tracking music state
        this.musicStarted = false;
        this.victoryMusicStarted = false;
        this.deathMusicStarted = false;

        // TODO:  Create two cubes, including one with the default texture coordinates (from 0 to 1), and one with the modified
        //        texture coordinates as required for cube #2.  You can either do this by modifying the cube code or by modifying
        //        a cube instance's texture_coords after it is already created.
        this.shapes = {
            box_1: new Cube(),
            box_2: new Cube(),
            axis: new Axis_Arrows(),
            grass_floor: new Cube(),
            wall:new Cube(),
            sky: new defs.Subdivision_Sphere(4),
            rock: new Shape_From_File("assets/rock.obj"),
            grass: new Shape_From_File("assets/grass.obj"),
            tall_rock: new Shape_From_File("assets/tall_rock.obj"),
            food_santa_claus: new Shape_From_File("assets/food_santa_claus.obj"),
            rock_wall: new Shape_From_File("assets/rock_wall.obj"),
            rock_wall_2: new Shape_From_File("assets/rock_wall_2.obj"),
            rock_boss: new Shape_From_File("assets/rock_boss.obj"),
            rock_boss_spell: new Shape_From_File("assets/rock.obj"),
            sphere: new defs.Subdivision_Sphere(4),
            text: new Text_Line(35),
            cube: new Cube()
        }

        //We can use this to make object disappeared. So when this equals to false, then the object disappeared.
        this.shapes.rock.canDraw = true;

        //this gives better textures for the floor and walls
        for (let i = 0; i< this.shapes.grass_floor.arrays.texture_coord.length; i++)
        {
            this.shapes.grass_floor.arrays.texture_coord[i][0] *= 50;
            this.shapes.grass_floor.arrays.texture_coord[i][1] *= 50;
        }

        for (let i = 0; i< this.shapes.wall.arrays.texture_coord.length; i++)
        {
            this.shapes.wall.arrays.texture_coord[i][0] *= 10;
            this.shapes.wall.arrays.texture_coord[i][1] *= 10;
        }

        for (let i = 0; i< this.shapes.sky.arrays.texture_coord.length; i++)
        {
            this.shapes.sky.arrays.texture_coord[i][0] *= 10;
            this.shapes.sky.arrays.texture_coord[i][1] *= 10;
        }


        // TODO:  Create the materials required to texture both cubes with the correct images and settings.
        //        Make each Material from the correct shader.  Phong_Shader will work initially, but when
        //        you get to requirements 6 and 7 you will need different ones.
        this.materials = {
            phong: new Material(new Textured_Phong(), {
                color: hex_color("#000000"),
            }),
            texture: new Material(new Texture_Rotate(), {
                color: hex_color("#000000"),
                ambient: 1.0, diffusivity: 0.1, specularity: 0.1,
                texture: new Texture("assets/ucla.png","NEAREST")
            }),
            texture_2: new Material(new Texture_Scroll_X(), {
                color: hex_color("#000000"),
                ambient: 1.0, diffusivity: 0.1, specularity: 0.1,
                texture: new Texture("assets/USC.png", "LINEAR_MIPMAP_LINEAR")
            }),
            texture_grass_floor: new Material(new Textured_Phong(), {
                color: hex_color("#ffffff"),
                ambient: 0.35, diffusivity: 1, specularity: 0.1,
                texture: new Texture("assets/grass_floor_texture.jpg")
            }),
            texture_wall: new Material(new Textured_Phong(), {
                color: hex_color("#ffffff"),
                ambient: 0.35, diffusivity: 1, specularity: 0.1,
                texture: new Texture("assets/cloud_wall_texture.png")
            }),
            texture_cloud: new Material(new Textured_Phong(), {
                color: hex_color("#ffffff"),
                ambient: 0.35, diffusivity: 1, specularity: 0.1,
                texture: new Texture("assets/cloud_wall_texture.png")
            }),
            rock_material: new Material(new defs.Fake_Bump_Map(1), {
                color: color(.5, .5, .5, 1),
                ambient: 0.35, diffusivity: 1, specularity: 1, texture: new Texture("assets/rock_2_texture.png")
            }),
            tall_rock_material: new Material(new defs.Fake_Bump_Map(1), {
                color: color(.5, .5, .5, 1),
                ambient: 0.35, diffusivity: 1, specularity: 1, texture: new Texture("assets/tall_rock_texture.jpg")
            }),
            grass_material: new Material(new Textured_Phong(), {
                ambient: 0.35, diffusivity: 1, specularity: 1, color: hex_color("#66ff00"),
            }),
            food_santa_claus_material: new Material(new defs.Fake_Bump_Map(1), {
                color: color(.5, .5, .5, 1),
                ambient: 0.35, diffusivity: 1, specularity: 1, texture: new Texture("assets/food_santa_claus_texture.jpg")
            }),
            rock_wall_material: new Material(new defs.Fake_Bump_Map(1), {
                color: color(.5, .5, .5, 1),
                ambient: 0.3, diffusivity: 1, specularity: 1, texture: new Texture("assets/tall_rock_texture.jpg")
            }),
            rock_boss_material: new Material(new defs.Fake_Bump_Map(1), {
                color: color(.5, .5, .5, 1),
                ambient: 0.3, diffusivity: 1, specularity: 1, texture: new Texture("assets/rock_boss_texture.tif")
            }),


            sun: new Material(new defs.Phong_Shader(), {ambient: 1, color: color(1, 0, 1, 1)}),

            //---------------------------------------------------------------------------------
            sans_texture: new Material(new Textured_Phong(), {
                color: hex_color("#000000"),
                ambient: 1.0, diffusivity: 0.1, specularity: 0.1,
                texture: new Texture("assets/snake_texture.jpg","NEAREST")
            }),
            snake_texture: new Material(new Texture_Rotate(), {
                color: hex_color("#000000"),
                ambient: 1.0, diffusivity: 0.1, specularity: 0.1,
                texture: new Texture("assets/snake_texture2.jpg","NEAREST")
            }),
            //Guanqun 3/2/2021
            sphere_texture: new Material(new Textured_Phong(),
                {ambient: .2, diffusivity: .8, specularity: .5, color: hex_color("#f1e503")}),
            //---------------------------------------------------------------------------------


            start_background: new Material(new Phong_Shader(), {
                color: color(0, 0.5, 0.5, 1), ambient: 0,
                diffusivity: 0, specularity: 0, smoothness: 20
            }),
            // to show text that is attached to the screen:
            text_image_screen: new Material(new Textured_Phong(1), {
                ambient: 1, diffusivity: 0, specularity: 0,
                texture: new Texture("assets/text.png")
            }),
            // To show text you need a Material like this one:
            text_image: new Material(new Textured_Phong(1), {
                ambient: 1, diffusivity: 0, specularity: 0,
                texture: new Texture("assets/text.png")
            }),
        }

        this.initial_camera_location = Mat4.look_at(vec3(0, 10, 20), vec3(0, 0, 0), vec3(0, 1, 0));

        this.grass_floor = Mat4.translation(0, -2, 0).times(Mat4.scale(200, 0.1, 200));

        function getRandomInt(max) {
            return Math.floor((Math.random()>=0.5? 1 : -1) * Math.random() * Math.floor(max));
        }

        this.Grass_locations_array = [0];
        this.howManyGrass = 700;
        for (var i = 0; i < this.howManyGrass; i++){
            this.Grass_locations_array.push(getRandomInt(200));
        }
        this.grass = Mat4.translation(0,2,-15).times(Mat4.scale(3,3,3));


        this.tall_rock_locations_array = [0];
        this.howManyTallRocks = 50;
        for (var i = 0; i < this.howManyTallRocks; i++){
            this.tall_rock_locations_array.push(getRandomInt(200));
        }

        for (var i = 0; i < this.howManyTallRocks; i++){
            if(Math.abs(this.tall_rock_locations_array[i]) < 20 || Math.abs(this.tall_rock_locations_array[i+1]) < 20){
                this.tall_rock_locations_array[i] += 20;
                this.tall_rock_locations_array[i+1] += 20;
            }
        }

        this.food_santa_claus_x_array = [0];
        this.food_santa_claus_z_array = [0];
        this.howManyFoodSantaClus = 100;
        for (var i = 0; i < this.howManyFoodSantaClus; i++){
            this.food_santa_claus_x_array.push(getRandomInt(200));
            this.food_santa_claus_z_array.push(getRandomInt(200));
        }

        this.rock_boss_spell_locations_array= [0];
        this.howManyBossSpells = 300;
        for (var i = 0; i < this.howManyBossSpells; i++){
            this.rock_boss_spell_locations_array.push(getRandomInt(200));
        }

        //this.rock = Mat4.translation(0, 2, 0).times(Mat4.scale(0.001, 0.001, 0.001));
        this.shapes.rock.canDraw = false;

        //---------------------------------------------------------------------------------

        this.set_move = false;

        // for food and stone numbers
        // currently have 200 food and tall stone items
        this.food_stone_storage = new Array(this.howManyTallRocks + this.howManyFoodSantaClus).fill(0);
        this.food_collision_detected = new Array(this.howManyFoodSantaClus).fill(false);
        this.turned = new Array(this.howManyTallRocks).fill(false);

        this.boundary_turned = new Array(4).fill(false); // sides of boundary is 4
        this.boundary_collided = new Array(4).fill(false); // sides of boundary is 4
        this.boss_turned = false;

        //*******************************
        // Keeping track of direction
        this.snake_direction = 1;            //variables for which direction snake is going
        this.snake_x_coord = new Array(1,0,0,0,0,0,0,0);
        this.snake_z_coord = new Array(1,0,0,0,0,0,0,0);

        //Keeping track of snake size, here default size = 105 cubes for now;
        this.snake_length = 8;

        //*******************************
        //--------------------------------------------------------------------------------

    }

    make_control_panel() {
        this.key_triggered_button("left(j)", ["j"], () => {
            // TODO:  Requirement 5b:  Set a flag here that will toggle your outline on and off
            if(this.snake_direction>1)
                this.snake_direction--;
            else
                this.snake_direction = 4;
        });
        this.key_triggered_button("right(l)", ["l"], () => {
            // TODO:  Requirement 5b:  Set a flag here that will toggle your outline on and off
            if(this.snake_direction<4)
                this.snake_direction++;
            else
                this.snake_direction = 1;
        });
        this.new_line(); this.new_line();
        this.key_triggered_button("Start Game", ["p"], () => {
            this.startGame = true;
            // Only play if the song has never been played before
            if (!this.musicStarted) {
                this.background_music.play();
                this.musicStarted = true;
            }
        });
        this.new_line(); this.new_line();

        // Restart Game
        this.key_triggered_button("Restart Game", ["r"], () => {
            this.reset();
        });

        this.new_line(); this.new_line();
    }

    Create_Environment(context, program_state, t){
        let model_transform_sky = Mat4.identity();
        let model_transform_grass = Mat4.identity();

        //This draws floor
        this.shapes.grass_floor.draw(context, program_state, this.grass_floor, this.materials.texture_grass_floor);

        //this draws sky
        model_transform_sky = model_transform_sky.times(Mat4.scale(300,300,300));
        this.shapes.sky.draw(context, program_state, model_transform_sky, this.materials.texture_cloud);

        //this draws grass
        for(var i = 0; i < this.howManyGrass; i++)
        {
            model_transform_grass = Mat4.translation(this.Grass_locations_array[i+1],2,this.Grass_locations_array[i]).times(Mat4.scale(3,3,3));
            this.shapes.grass.draw(context, program_state, model_transform_grass, this.materials.grass_material);
        }
    }

    Boss_Stone (context, program_state, t) {
        let model_transform_rock_boss = Mat4.identity();
        //this draws the boss at the center of the map
        model_transform_rock_boss = Mat4.scale(3,3,3).times(Mat4.translation(0,2+(Math.sin(5*t)/2),-20));
        this.shapes.rock_boss.draw(context, program_state, model_transform_rock_boss, this.materials.rock_boss_material);

        //boss collision
        var boss_location = [...model_transform_rock_boss.transposed()[3]];
        if (Math.abs(this.snake_x_coord[0] - boss_location[0]) <= 10 && Math.abs(this.snake_z_coord[0] - boss_location[2]) <= 6) {
            // if the snake length is longer than 18, it defeats the boss;
            // otherwise, it loses.
            if (this.snake_length < 13) {
                if (!this.boss_turned) {
                    this.loseGame = true;
                    this.endGame = true;
                    this.boss_turned = true;
                }
            } else {
                if (!this.boss_turned) {
                    this.victory = true;
                    this.endGame = true;
                    this.boss_turned = true;
                }
            }
        } else {
            this.boss_turned = false;
        }
    }

    Tall_Stone(context, program_state) {
        let model_transform_tall_rock = Mat4.identity();
        //this draws tall rocks
        for(var i = 0; i < this.howManyTallRocks; i++)
        {
            model_transform_tall_rock = Mat4.translation(this.tall_rock_locations_array[i+1],2,this.tall_rock_locations_array[i]).times(Mat4.scale(5,10,5));
            this.shapes.tall_rock.draw(context, program_state, model_transform_tall_rock, this.materials.tall_rock_material);

            // update the storage of food and stone objects.
            // 0, 1, 2, 3rd indices are information of food/stone model transform
            this.food_stone_storage[i] = [...model_transform_tall_rock.transposed()[3]];

            if (Math.abs(this.snake_x_coord[0] - this.food_stone_storage[i][0]) <= 10 && Math.abs(this.snake_z_coord[0] - this.food_stone_storage[i][2]) <= 8) {
                // once there is a collision between snake and stone, the snake just turns in the opposite direction; otherwise, do nothing.
                if (!this.turned[i]) {
                    this.loseGame = true;
                    this.endGame = true;
                    this.turned[i] = true;
                }
            }
            else {
                this.turned[i] = false;
            }
        }
    }

    Food_Santa_Claus (context, program_state, t) {
        let model_transform_food_santa_clus = Mat4.identity();
        //this draws food santa clus
        for(var i = 0; i < this.howManyFoodSantaClus; i++)
        {
            model_transform_food_santa_clus = Mat4.translation(this.food_santa_claus_x_array[i],0.5 + Math.sin(t),this.food_santa_claus_z_array[i]).times(Mat4.scale(1,1,1));

            // update the storage of food and stone objects.
            // 0, 1, 2, 3rd indices are information of food/stone model transform
            this.food_stone_storage[i+this.howManyTallRocks] = [...model_transform_food_santa_clus.transposed()[3]];

            // if distance between camera and stone in both x and z direction are less than stone's x and z dimension, there is a collision.
            if (Math.abs(this.snake_x_coord[0] - this.food_stone_storage[i+this.howManyTallRocks][0]) < 2 && Math.abs(this.snake_z_coord[0] - this.food_stone_storage[i+this.howManyTallRocks][2]) < 2) {
                //this.food_collision_detected[i] = true;
                this.food_santa_claus_x_array.splice(i,1);
                this.food_santa_claus_z_array.splice(i,1);
                i--;
                this.howManyFoodSantaClus--;
                this.snake_x_coord.push(0);
                this.snake_z_coord.push(0);
                this.snake_length++;
            }

            // once there is a collision between snake and food, just don't draw the food; otherwise, still draw the food.
            this.shapes.food_santa_claus.draw(context, program_state, model_transform_food_santa_clus, this.materials.food_santa_claus_material);
        }
    }

    Snake (context, program_state) {
        let snake_model_transform = Mat4.identity(); //making model transform
        //Snake Code

        let first_x = this.snake_x_coord[0];                //keeping track of x coordinate of leading cube
        let first_z = this.snake_z_coord[0];                //keeping track of y coordinate of leading cube

        if (this.snake_direction == 4)        //if you press left
        {
            this.snake_x_coord[0] = this.snake_x_coord[0]-0.5;     //switch to go left so -x direction
        }
        else if (this.snake_direction == 2)   //if you press right
        {
            this.snake_x_coord[0] = this.snake_x_coord[0]+0.5;     //switch to go right so +x direction
        }
        else if (this.snake_direction == 3)  //if you press down
        {
            this.snake_z_coord[0] = this.snake_z_coord[0]+0.5;     //switch to go down so -y direction
        }
        else                //if you press up (or left, right, down all not pressed)
        {

            this.snake_z_coord[0] = this.snake_z_coord[0]-0.5;     //switch to go up so +y direction
        }

        let x_hold = 0; //variables to hold value later
        let z_hold = 0;

        for(let i = 1; i<this.snake_length; i++)        //loop through size of snake
        {
            x_hold = first_x;           //hold x and y value to use
            z_hold = first_z;

            first_x = this.snake_x_coord[i];        //summary: snake_x_coord[i] = snake_x_coord[i-1] for these next 4 lines
            first_z = this.snake_z_coord[i];

            this.snake_x_coord[i]=x_hold;
            this.snake_z_coord[i]=z_hold;

        }

        for(let i = 0; i<this.snake_length; i++)    //loop through size of snake
        {

            snake_model_transform = Mat4.identity();    //reset translation per for loop so it doesn't stack
            snake_model_transform = snake_model_transform.times(Mat4.translation(this.snake_x_coord[i], 0, this.snake_z_coord[i])); //translate cube to correct spot

            if(this.snake_length<13)
                this.shapes.sphere.draw(context, program_state, snake_model_transform, this.materials.sans_texture); //draw all spheres
            else
                this.shapes.sphere.draw(context, program_state, snake_model_transform, this.materials.snake_texture); //draw different texture when snake is powered up

        }
    }

    Boundaries (context, program_state) {
        let model_transform_rock_wall_back = Mat4.identity();
        let model_transform_rock_wall_right = Mat4.identity();
        let model_transform_rock_wall_left = Mat4.identity();
        let model_transform_rock_wall_front = Mat4.identity();
        //this draw walls  3/5/2021
        model_transform_rock_wall_back = Mat4.scale(10,10,10).times(Mat4.translation(22,0,20));
        for (var i = 0; i < 10; i++)
        {
            model_transform_rock_wall_back = model_transform_rock_wall_back.times(Mat4.translation(-4,0,0));
            this.shapes.rock_wall.draw(context, program_state, model_transform_rock_wall_back, this.materials.rock_wall_material);
        }

        model_transform_rock_wall_front = Mat4.scale(10,10,10).times(Mat4.translation(22,0,-20));
        for (var i = 0; i < 10; i++)
        {
            model_transform_rock_wall_front = model_transform_rock_wall_front.times(Mat4.translation(-4,0,0));
            this.shapes.rock_wall.draw(context, program_state, model_transform_rock_wall_front, this.materials.rock_wall_material);
        }

        model_transform_rock_wall_left = model_transform_rock_wall_left.times(Mat4.scale(10,10,10)).times(Mat4.translation(-19.8,0,22));
        for (var i = 0; i < 10; i++)
        {
            model_transform_rock_wall_left = model_transform_rock_wall_left.times(Mat4.translation(0,0,-4));
            this.shapes.rock_wall_2.draw(context, program_state, model_transform_rock_wall_left, this.materials.rock_wall_material);
        }

        model_transform_rock_wall_right = model_transform_rock_wall_right.times(Mat4.scale(10,10,10)).times(Mat4.translation(19.8,0,22));
        for (var i = 0; i < 10; i++)
        {
            model_transform_rock_wall_right = model_transform_rock_wall_right.times(Mat4.translation(0,0,-4));
            this.shapes.rock_wall_2.draw(context, program_state, model_transform_rock_wall_right, this.materials.rock_wall_material);
        }

        // boundary collision: once the snake hits the boundary, turn the snake around
        // for boundary_turned array:
        // index 0: left boundary
        // index 1: right boundary
        // index 2: top boundary
        // index 3: bottom boundary
        // left collided
        if (Math.abs(this.snake_x_coord[0] - (-200)) <= 10 && this.boundary_turned[0] == false) {
            this.boundary_collided[0] = true;
        }
        // right collided
        if (Math.abs(this.snake_x_coord[0] - 200) <= 10 && this.boundary_turned[1] == false) {
            this.boundary_collided[1] = true;
        }
        // top collided
        if (Math.abs(this.snake_z_coord[0] - (-200)) <= 10 && this.boundary_turned[2] == false) {
            this.boundary_collided[2] = true;
        }
        // bottom collided
        if (Math.abs(this.snake_z_coord[0] - 200) <= 10 && this.boundary_turned[3] == false) {
            this.boundary_collided[3] = true;
        }

        for (var i = 0; i < 4; i++) {
            if (this.boundary_collided[i] && !this.boundary_turned[i]) {
                this.loseGame = true;
                this.endGame = true;

                this.boundary_turned[i] = true;
                this.boundary_collided[i] = false;
            } else if (Math.abs(this.snake_x_coord[0] - (-200)) > 10 && Math.abs(this.snake_x_coord[0] - 200) > 10
                && Math.abs(this.snake_z_coord[0] - (-200)) > 10 && Math.abs(this.snake_z_coord[0] - 200) > 10) {
                // when not collided, update the boolean to not turned
                this.boundary_turned[i] = false;
            }
        }
    }

    //---------------------------------------------------------------------------------------------------------------------------------------
    reset() {
        this.startGame = false;
        this.endGame = false;
        this.victory = false;
        this.loseGame = false;
        // Pause since game is over
        this.background_music.pause();
        this.background_music = new Audio('main_music.mp3');
        this.musicStarted = false;
        this.victoryMusicStarted = false;
        this.deathMusicStarted = false;

        this.snake_direction = 1; //varialbe for which direction snake is going
        this.snake_x_coord = new Array(1,0,0,0,0,0,0,0);
        this.snake_z_coord = new Array(1,0,0,0,0,0,0,0);

        //keeping track of snake size, here default size = 105 cubes
        this.snake_length = 8;
    }


    // Base setup for splash screens (start, pause, end game, win game)
    baseScreenSetup(context, program_state, model_transform) {
        // Set lights
        program_state.lights = [new Light(vec4(0, 1, 1, 0), color(1, 1, 1, 1), 1000000)];
        // Set initial camera location
        program_state.set_camera(Mat4.look_at(...Vector.cast([0, 0, 4], [0, 0, 0], [0, 1, 0])));

        // Set initial position of box
        let start_message_transform = model_transform.times(Mat4.scale(2.5, 0.5, 0.5));
        this.shapes.cube.draw(context, program_state, start_message_transform, this.materials.start_background);
    }

    // Base functionality for drawing text on surface of splash screens
    baseDrawText(context, program_state, multi_line_string, cube_side) {
        for (let line of multi_line_string.slice(0, 30)) {
            // Set the string using set_string
            this.shapes.text.set_string(line, context.context);
            // Draw but scale down to fit box size
            this.shapes.text.draw(context, program_state, cube_side.times(Mat4.scale(.1, .1, .1)), this.materials.text_image);

            // Use post multiply to move down to the next line
            cube_side.post_multiply(Mat4.translation(0, -0.09, 0));
        }
    }

    // Initial game start screen
    startGameSetup(context, program_state, model_transform) {
        this.baseScreenSetup(context, program_state, model_transform);
        // Define text to be written
        let strings = ['\t\t\t\t\t\t\t\t\t\t\tSnake\n\n\n\nControls:J(left), L(right)\n\n\nCollect 5 cookies then beat\n\n\n\t\t\t\t\t\t\t\t\tthe boss\n\n\n\t\tPress (P) to Start.'];
        const multi_line_string = strings[0].split("\n");
        let cube_side = Mat4.rotation(0, 1, 0, 0)
            .times(Mat4.rotation(0, 0, 1, 0))
            .times(Mat4.translation(-1.8, 0, 0.9));
        // Draw text
        this.baseDrawText(context, program_state, multi_line_string, cube_side);
    }


    // Game Lost Screen
    gameLostScreen(context, program_state, model_transform) {
        this.baseScreenSetup(context, program_state, model_transform);
        if(this.deathMusicStarted == false) {
            this.background_music.pause();
            this.background_music = new Audio('death_music.mp3');
            this.background_music.play();
            this.deathMusicStarted = true;
        }
        // Define text to be written
        let strings = ['\t\t\t\t\t\t\t\tGame Over. \n\n\n\t\t\t\tPress R To Restart.'];
        const multi_line_string = strings[0].split("\n");
        let cube_side = Mat4.rotation(0, 1, 0, 0)
            .times(Mat4.rotation(0, 0, 1, 0))
            .times(Mat4.translation(-1.9, 0, 0.9));
        // Draw text
        this.baseDrawText(context, program_state, multi_line_string, cube_side);
    }

    // Game Won Screen
    gameWonScreen(context, program_state, model_transform) {
        this.baseScreenSetup(context, program_state, model_transform);
        if(this.victoryMusicStarted == false) {
            this.background_music.pause();
            this.background_music = new Audio('victory_music.mp3');
            this.background_music.play();
            this.victoryMusicStarted = true;
        }
        // Define text to be written
        let strings = ['\t\tCongratulations! \n\n\nYou Beat The Monster\n\n\nPress(R) To Play Again'];
        const multi_line_string = strings[0].split("\n");
        let cube_side = Mat4.rotation(0, 1, 0, 0)
            .times(Mat4.rotation(0, 0, 1, 0))
            .times(Mat4.translation(-1, 0, 0.9));
        // Draw text
        this.baseDrawText(context, program_state, multi_line_string, cube_side);
    }

    // Check game status : Determines if player has won or lost
    getGameState() {
        // If all objects have been found
        if (this.currentGameTime > 0) {
            for (var key in this.object_found) {
                if (this.object_found.hasOwnProperty(key)) {
                    if (this.object_found[key] == false) {
                        this.victory = false;
                        return;
                    }
                }
            }
            this.victory = true;
            this.endGame = true;
        }
        // All objects found but time has run out
        else if ((this.allObjectsFound) && (this.currentGameTime <= 0)) {
            this.victory = false;
        }
        // If time has run out
        else if (this.currentGameTime <= 0) {
            this.endGame = true;
            this.victory = false;
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------------------

    display(context, program_state) {
        if (!context.scratchpad.controls) {
            this.children.push(context.scratchpad.controls = new defs.Movement_Controls());
            // Define the global camera and projection matrices, which are stored in program_state.
            program_state.set_camera(Mat4.translation(0, 0, -50));
        }
        program_state.set_camera(Mat4.look_at(vec3(this.snake_x_coord[0], 20, this.snake_z_coord[0]+20), vec3(this.snake_x_coord[0], 0, this.snake_z_coord[0]), vec3(0, 1, 0)));

        program_state.projection_transform = Mat4.perspective(
            Math.PI / 4, context.width / context.height, 1, 1000);

        const light_position = vec4(0, 0, 5, 5);
        program_state.lights = [new Light(light_position, color(1, 1, 1, 1), 10)];

        let t = program_state.animation_time / 1000, dt = program_state.animation_delta_time / 1000;

        let model_transform = Mat4.identity();

        // Start game is set to true
        if (this.startGame) {
            // If the game is not over
            if (!this.endGame) {

                // Snake
                this.Snake(context, program_state);

                // Tall Stones
                this.Tall_Stone(context, program_state);

                // Food objects: Santa Claus
                this.Food_Santa_Claus (context, program_state, t);

                // Boundaries
                this.Boundaries (context, program_state);

                // Boss Stone
                this.Boss_Stone (context, program_state, t);

                // Environment
                this.Create_Environment(context, program_state, t);

                // Initialize mouse position
                let mouse_x = 0;
                let mouse_y = 0;
                // Update mouse position
                if (defs.canvas_mouse_pos) {
                    mouse_x = defs.canvas_mouse_pos[0];
                    mouse_y = defs.canvas_mouse_pos[1];
                }
            }
            // Game over
            else {
                if (!this.background_music.paused) {
                   // this.background_music.pause();
                }
                // Check for victory and display victory screen
                if (this.victory) {
                    this.gameWonScreen(context, program_state, model_transform);

                }
                // Otherwise the user lost, so display lost screen
                else if (this.loseGame){
                    this.gameLostScreen(context, program_state, model_transform);
                }
            }
        }
        // Start game is set to false, so display message indicating controls to start game
        else {
            this.startGameSetup(context, program_state, model_transform);
        }
    }
}

//Use continuous scrolling the texture map on cube #2. Translate the texture varying the s texture coordinate by 2 texture units per second
class Texture_Scroll_X extends Textured_Phong {
    // TODO:  Modify the shader below (right now it's just the same fragment shader as Textured_Phong) for requirement #6.
    fragment_glsl_code() {
        return this.shared_glsl_code() + `
            varying vec2 f_tex_coord;
            uniform sampler2D texture;
            uniform float animation_time;
            
            void main(){
                // Sample the texture image in the correct place:
                
                vec4 tex_color = texture2D( texture, vec2(f_tex_coord.x-(2.0 * mod(animation_time, 8.0)), f_tex_coord.y) );
                
                if( tex_color.w < .01 ) discard;
                                                                         // Compute an initial (ambient) color:
                gl_FragColor = vec4( ( tex_color.xyz + shape_color.xyz ) * ambient, shape_color.w * tex_color.w ); 
                                                                         // Compute the final color with contributions from lights:
                gl_FragColor.xyz += phong_model_lights( normalize( N ), vertex_worldspace );
        } `;
    }
}


class Texture_Rotate extends Textured_Phong {
    // TODO:  Modify the shader below (right now it's just the same fragment shader as Textured_Phong) for requirement #7.
    fragment_glsl_code() {
        return this.shared_glsl_code() + `
            varying vec2 f_tex_coord;
            uniform sampler2D texture;
            uniform float animation_time;
            void main(){
                
                //Rotate the texture map itself on all faces of cube #1 around the center of each face at a rate of 15 rpm
                
                // Sample the texture image in the correct place:
                float rpm = 15.0;
                float translate =  0.5;
                float theta = 3.14 * 2.0 * mod(animation_time*(rpm/60.0), 1.0);
                mat2 rotation = mat2( cos(theta), -sin(theta), sin(theta), cos(theta) );
                
                vec4 tex_color = texture2D( texture, rotation*(f_tex_coord.xy-translate)+translate );
                
                if( tex_color.w < .01 ) discard;
                                                                         // Compute an initial (ambient) color:
                gl_FragColor = vec4( ( tex_color.xyz + shape_color.xyz ) * ambient, shape_color.w * tex_color.w ); 
                                                                         // Compute the final color with contributions from lights:
                gl_FragColor.xyz += phong_model_lights( normalize( N ), vertex_worldspace );
        } `;
    }
}